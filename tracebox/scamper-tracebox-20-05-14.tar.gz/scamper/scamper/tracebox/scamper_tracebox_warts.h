/*
 * scamper_tracebox_warts.h
 *
 * Copyright (C) 2003-2006 Matthew Luckie
 * Copyright (C) 2003-2011 The University of Waikato
 * Copyright (C) 2008 Alistair King
 * Copyright (C) 2012      The Regents of the University of California
 * Copyright (C) 2013-2014  Korian Edeline, University of Liège
 *  
 *
 * Authors: Matthew Luckie
 *          Doubletree implementation by Alistair King
 *          Tracebox implementation by Korian Edeline
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 2.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * This work is funded by the European Commission funded 
 * mPlane ICT-318627 project (http://www.ict-mplane.eu).
 *
 */

#ifndef __SCAMPER_FILE_WARTS_TRACEBOX_H
#define __SCAMPER_FILE_WARTS_TRACEBOX_H

int scamper_file_warts_tracebox_write(const scamper_file_t *sf,
				  const scamper_tracebox_t *tracebox);

int scamper_file_warts_tracebox_read(scamper_file_t *sf, const warts_hdr_t *hdr,
				 scamper_tracebox_t **tracebox_out);

#endif
