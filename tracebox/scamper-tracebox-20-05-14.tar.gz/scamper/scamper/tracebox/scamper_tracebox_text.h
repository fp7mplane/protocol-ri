/*
 * scamper_tracebox_text.h
 *
 * Copyright (C) 2003-2006 Matthew Luckie
 * Copyright (C) 2003-2011 The University of Waikato
 * Copyright (C) 2008 Alistair King
 * Copyright (C) 2012      The Regents of the University of California
 * Copyright (C) 2013-2014  Korian Edeline, University of Liège
 *  
 *
 * Authors: Matthew Luckie
 *          Doubletree implementation by Alistair King
 *          Tracebox implementation by Korian Edeline
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 2.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * This work is funded by the European Commission funded 
 * mPlane ICT-318627 project (http://www.ict-mplane.eu).
 *
 */

#ifndef __SCAMPER_FILE_TEXT_TRACEBOX_H
#define __SCAMPER_FILE_TEXT_TRACEBOX_H

#define TRACEBOX_PRINT_MODE_STANDARD           0x0
#define TRACEBOX_PRINT_MODE_FRAGS              0x1              
#define TRACEBOX_PRINT_MODE_FULL_ICMP          0x2    
#define TRACEBOX_PRINT_MODE_PROXY              0x4
#define TRACEBOX_PRINT_MODE_STATEFULL          0x5  
#define TRACEBOX_PRINT_MODE_SIMPLIFIED_OUTPUT  0x6 

uint32_t byte_reverse_32(uint32_t num);
uint16_t byte_reverse_16(uint16_t num);
char * compute_differences(const scamper_tracebox_t *tracebox, const uint8_t *pkt1, const uint8_t *pkt2, const uint8_t type, const uint8_t network, const uint8_t transport);

int scamper_file_text_tracebox_write(const scamper_file_t *sf,
				 const scamper_tracebox_t *tracebox);

#endif
