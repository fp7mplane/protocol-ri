/*
 * scamper_do_tracebox.h
 *
 * @author: K.Edeline
 */

#ifndef __SCAMPER_DO_TRACEBOX_H
#define __SCAMPER_DO_TRACEBOX_H

const char *scamper_do_tracebox_usage(void);

void *scamper_do_tracebox_alloc(char *str);

void scamper_do_tracebox_free(void *data);

scamper_task_t *scamper_do_tracebox_alloctask(void *data,
					  scamper_list_t *list,
					  scamper_cycle_t *cycle);

int scamper_do_tracebox_arg_validate(int argc, char *argv[], int *stop);

void scamper_do_tracebox_cleanup(void);
int scamper_do_tracebox_init(void);


#endif /*__SCAMPER_DO_TRACEBOX_H */ * 
