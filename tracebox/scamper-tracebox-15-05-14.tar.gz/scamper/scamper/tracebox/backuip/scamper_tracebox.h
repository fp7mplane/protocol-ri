/*
 * scamper_tracebox.h
 *
 *
 *
 * @author: K.Edeline
 */

#ifndef __SCAMPER_TRACEBOX_H
#define __SCAMPER_TRACEBOX_H

/* types of tracebox tests */
#define SCAMPER_TRACEBOX_TYPE_PMTUD              1
#define SCAMPER_TRACEBOX_TYPE_ECN                2
#define SCAMPER_TRACEBOX_TYPE_NULL               3
#define SCAMPER_TRACEBOX_TYPE_SACK_RCVR          4

/* application layer protocols supported by the tracebox test */
/*
#define SCAMPER_TRACEBOX_APP_HTTP                1
#define SCAMPER_TRACEBOX_APP_SMTP                2
#define SCAMPER_TRACEBOX_APP_DNS                 3
#define SCAMPER_TRACEBOX_APP_FTP                 4
*/
#define SCAMPER_TRACEBOX_APP_DEFAULT             1


/* generic tracebox results */
#define SCAMPER_TRACEBOX_RESULT_NONE             0 /* no result */
#define SCAMPER_TRACEBOX_RESULT_TCP_NOCONN       1 /* no connection */
#define SCAMPER_TRACEBOX_RESULT_TCP_RST          2 /* Early reset */
#define SCAMPER_TRACEBOX_RESULT_TCP_ERROR        3 /* TCP Error */
#define SCAMPER_TRACEBOX_RESULT_ERROR            4 /* System error */
#define SCAMPER_TRACEBOX_RESULT_ABORTED          5 /* Test aborted */
#define SCAMPER_TRACEBOX_RESULT_TCP_NOCONN_RST   6 /* no connection: rst rx */
#define SCAMPER_TRACEBOX_RESULT_HALTED           7 /* halted */
#define SCAMPER_TRACEBOX_RESULT_TCP_BADOPT       8 /* bad TCP option */
#define SCAMPER_TRACEBOX_RESULT_TCP_FIN          9 /* early fin */
#define SCAMPER_TRACEBOX_RESULT_TCP_ZEROWIN      10 /* zero window */

/* possible PMTUD test results */
#define SCAMPER_TRACEBOX_RESULT_PMTUD_NOACK      20 /* no ACK of request */
#define SCAMPER_TRACEBOX_RESULT_PMTUD_NODATA     21 /* no data received */
#define SCAMPER_TRACEBOX_RESULT_PMTUD_TOOSMALL   22 /* packets too small */
#define SCAMPER_TRACEBOX_RESULT_PMTUD_NODF       23 /* DF not set (IPv4 only) */
#define SCAMPER_TRACEBOX_RESULT_PMTUD_FAIL       24 /* did not reduce pkt size */
#define SCAMPER_TRACEBOX_RESULT_PMTUD_SUCCESS    25 /* responded correctly */
#define SCAMPER_TRACEBOX_RESULT_PMTUD_CLEARDF    26 /* cleared DF in response */

/* possible ECN test results */
#define SCAMPER_TRACEBOX_RESULT_ECN_SUCCESS      30 /* responded correctly */
#define SCAMPER_TRACEBOX_RESULT_ECN_INCAPABLE    31 /* no ece on syn/ack */
#define SCAMPER_TRACEBOX_RESULT_ECN_BADSYNACK    32 /* bad syn/ack */
#define SCAMPER_TRACEBOX_RESULT_ECN_NOECE        33 /* no ECN echo */
#define SCAMPER_TRACEBOX_RESULT_ECN_NOACK        34 /* no ack of request */
#define SCAMPER_TRACEBOX_RESULT_ECN_NODATA       35 /* no data received */

/* possible NULL test results */
#define SCAMPER_TRACEBOX_RESULT_NULL_SUCCESS     40 /* responded correctly */
#define SCAMPER_TRACEBOX_RESULT_NULL_NODATA      41 /* no data received */

/* possible SACK-RCVR test results */
#define SCAMPER_TRACEBOX_RESULT_SACK_INCAPABLE      50 /* not capable of SACK */
#define SCAMPER_TRACEBOX_RESULT_SACK_RCVR_SUCCESS   51 /* responded correctly */
#define SCAMPER_TRACEBOX_RESULT_SACK_RCVR_SHIFTED   52 /* shifted sack blocks */
#define SCAMPER_TRACEBOX_RESULT_SACK_RCVR_TIMEOUT   53 /* missing ack */
#define SCAMPER_TRACEBOX_RESULT_SACK_RCVR_NOSACK    54 /* missing sack blocks */

/* direction of recorded packet */
#define SCAMPER_TRACEBOX_PKT_DIR_TX              1
#define SCAMPER_TRACEBOX_PKT_DIR_RX              2

/* pmtud options */
#define SCAMPER_TRACEBOX_PMTUD_OPTION_BLACKHOLE  0x1 /* test blackhole behaviour */

/* null options */
#define SCAMPER_TRACEBOX_NULL_OPTION_TCPTS       0x01 /* tcp timestamps */
#define SCAMPER_TRACEBOX_NULL_OPTION_IPTS_SYN    0x02 /* IP TS option on SYN */
#define SCAMPER_TRACEBOX_NULL_OPTION_IPRR_SYN    0x04 /* IP RR option on SYN */
#define SCAMPER_TRACEBOX_NULL_OPTION_IPQS_SYN    0x08 /* IP QS option on SYN */
#define SCAMPER_TRACEBOX_NULL_OPTION_SACK        0x10 /* offer use of TCP SACK */

/* null results */
#define SCAMPER_TRACEBOX_NULL_RESULT_TCPTS       0x01 /* TCP timestamps OK */
#define SCAMPER_TRACEBOX_NULL_RESULT_SACK        0x02 /* use of TCP SACK OK */

typedef struct scamper_tracebox_pkt
{
  struct timeval       tv;
  uint8_t              dir;
  uint16_t             len;
  uint8_t             *data;
} scamper_tracebox_pkt_t;

typedef struct scamper_tracebox_app_http
{
  char                *host;
  char                *file;
} scamper_tracebox_app_http_t;

typedef struct scamper_tracebox_pmtud
{
  uint16_t             mtu;
  uint8_t              ptb_retx;
  uint8_t              options;
  scamper_addr_t      *ptbsrc;
} scamper_tracebox_pmtud_t;

typedef struct scamper_tracebox_null
{
  uint16_t             options;
  uint16_t             results;
} scamper_tracebox_null_t;

/*
 * scamper_tracebox
 *
 * parameters and results of a measurement conducted with tracebox.
 */
typedef struct scamper_tracebox
{
  scamper_list_t      *list;
  scamper_cycle_t     *cycle;
  uint32_t             userid;

  scamper_addr_t      *src;
  scamper_addr_t      *dst;
  uint16_t             sport;
  uint16_t             dport;

  uint8_t   donotresolv;
  uint8_t   udp;
  uint8_t   ipv6;
  uint16_t  maxhops;
  char     *probe;

  struct timeval       start;

  /* outcome of test */
  uint16_t             result;

  /* type of tracebox test and data specific to that test */
  uint8_t              type;
  void                *data;

  /* details of application protocol used */
  uint8_t              app_proto;
  void                *app_data;

  /* client and server mss values advertised */
  uint16_t             client_mss;
  uint16_t             server_mss;

  /* various generic retransmit values */
  uint8_t              syn_retx;
  uint8_t              dat_retx;

  /* packets collected as part of this test */
  scamper_tracebox_pkt_t **pkts;
  uint32_t             pktc;

  /* debug  */
  char* misc;
  uint32_t miscl;

} scamper_tracebox_t;

scamper_tracebox_t *scamper_tracebox_alloc(void);
void scamper_tracebox_free(scamper_tracebox_t *tracebox);

char *scamper_tracebox_res2str(const scamper_tracebox_t *tracebox, char *buf, size_t len);
char *scamper_tracebox_type2str(const scamper_tracebox_t *tracebox, char *buf, size_t len);

scamper_tracebox_pkt_t *scamper_tracebox_pkt_alloc(uint8_t dir, uint8_t *data,
					   uint16_t len, struct timeval *tv);
void scamper_tracebox_pkt_free(scamper_tracebox_pkt_t *pkt);
int scamper_tracebox_pkt_tcpdatabytes(const scamper_tracebox_pkt_t *pkt, uint16_t *bc);
int scamper_tracebox_pkt_tcpack(const scamper_tracebox_pkt_t *pkt, uint32_t *ack);

scamper_tracebox_pmtud_t *scamper_tracebox_pmtud_alloc(void);
void scamper_tracebox_pmtud_free(scamper_tracebox_pmtud_t *pmtud);

scamper_tracebox_null_t *scamper_tracebox_null_alloc(void);
void scamper_tracebox_null_free(scamper_tracebox_null_t *null);

scamper_tracebox_app_http_t *scamper_tracebox_app_http_alloc(char *host, char *file);
int scamper_tracebox_app_http_host(scamper_tracebox_app_http_t *http, const char *h);
int scamper_tracebox_app_http_file(scamper_tracebox_app_http_t *http, const char *f);
void scamper_tracebox_app_http_free(scamper_tracebox_app_http_t *http);

int scamper_tracebox_pkts_alloc(scamper_tracebox_t *tracebox, uint32_t count);
int scamper_tracebox_record_pkt(scamper_tracebox_t *tracebox, scamper_tracebox_pkt_t *pkt);

/*
 * scamper_tracebox_tcpq functions.
 *
 * these functions are used to maintain in-order processing of TCP packets
 * when the packets are received out of order.  for these routines to work
 * correctly, all TCP packets that are received in range must be processed
 * through the queue so that the queue knows what sequence number is
 * expected.
 *
 * scamper_tracebox_tcpq_alloc: allocate a new tcp data queue with an initial
 *  sequence number seeding the queue.
 *
 * scamper_tracebox_tcpq_free: free the tcp data queue.  the ff parameter is an
 *  optional free() function that can be called on all queue entry param
 *  fields.
 *
 * scamper_tracebox_tcpq_add: add a new segment to the queue.  the seq, flags,
 *  and length must be supplied.  the param field is an optional field that
 *  will be returned with the queue entry when the segment is returned in
 *  order.
 *
 * scamper_tracebox_tcpq_seg: return the sequence number and payload length of
 *  the next packet in line to be returned.  the segment remains in the queue.
 *  returns -1 if there is no segment in the queue, zero otherwise.
 *
 * scamper_tracebox_tcpq_pop: return the next queue entry that is next in line
 *  to be returned.  the segment is now the responsibility of the caller.
 *
 * scamper_tracebox_tcpq_sack: return a set of sack blocks that specify the
 *  state of the tcpq.  the caller must pass a pointer to an array of
 *  (c*2) uint32_t.  the routine returns the number of sack blocks
 *  computed given the constraint of c and the state of the queue.
 *
 * scamper_tracebox_tcpqe_free: free the queue entry passed in.  ff is an
 *  optional free() function that will be called on the param if not null.
 *
 */
typedef struct scamper_tracebox_tcpq scamper_tracebox_tcpq_t;
typedef struct scamper_tracebox_tcpqe
{
  uint32_t seq;
  uint16_t len;
  uint8_t  flags;
  uint8_t *data;
} scamper_tracebox_tcpqe_t;
scamper_tracebox_tcpq_t *scamper_tracebox_tcpq_alloc(uint32_t isn);
void scamper_tracebox_tcpq_free(scamper_tracebox_tcpq_t *q, void (*ff)(void *));
int scamper_tracebox_tcpq_add(scamper_tracebox_tcpq_t *q, uint32_t seq,
			  uint8_t flags, uint16_t len, uint8_t *data);
int scamper_tracebox_tcpq_seg(scamper_tracebox_tcpq_t *q,uint32_t *seq,uint16_t *len);
scamper_tracebox_tcpqe_t *scamper_tracebox_tcpq_pop(scamper_tracebox_tcpq_t *q);
int scamper_tracebox_tcpq_sack(scamper_tracebox_tcpq_t *q, uint32_t *blocks, int c);
void scamper_tracebox_tcpqe_free(scamper_tracebox_tcpqe_t *qe, void (*ff)(void *));

/*
 * convenience functions.
 *
 * scamper_tracebox_data_inrange: determine if a particular packet and length
 *  are in range or not.
 *
 * scamper_tracebox_data_seqoff: determine the difference in sequence number
 *  space between a and b handling wrapping.  this function assumes that
 *  the caller has used scamper_tracebox_data_inrange first to determine
 *  the packet is in the current window.
 *
 */
int scamper_tracebox_data_inrange(uint32_t rcv_nxt, uint32_t seq, uint16_t len);
int scamper_tracebox_data_seqoff(uint32_t rcv_nxt, uint32_t seq);

/*
 * scamper_tracebox_stats
 *
 * give some idea about what took place during the tracebox measurement.
 */
typedef struct scamper_tracebox_stats
{
  struct timeval synack_rtt;
  uint32_t       rx_xfersize;
  uint32_t       rx_totalsize;
  struct timeval xfertime;
} scamper_tracebox_stats_t;

int scamper_tracebox_stats(const scamper_tracebox_t *tracebox,scamper_tracebox_stats_t *stats);

#endif /* __SCAMPER_TRACEBOX_H */
